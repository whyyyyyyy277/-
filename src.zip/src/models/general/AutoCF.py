# -*- coding: UTF-8 -*-
# AutoCF (HKUDS/AutoCF) re-implementation for ReChorus2.0

import os
import logging
import numpy as np
import scipy.sparse as sp

import torch
import torch.nn as nn
import torch.nn.functional as F

from models.BaseModel import GeneralModel


class _LightGCNParamEncoder(nn.Module):
	"""
	A minimal LightGCN-style encoder that matches ReChorus LightGCN checkpoint keys:
	`encoder.embedding_dict.user_emb` / `encoder.embedding_dict.item_emb`.
	"""
	def __init__(self, user_num: int, item_num: int, emb_size: int):
		super().__init__()
		initializer = nn.init.xavier_uniform_
		self.embedding_dict = nn.ParameterDict({
			'user_emb': nn.Parameter(initializer(torch.empty(user_num, emb_size))),
			'item_emb': nn.Parameter(initializer(torch.empty(item_num, emb_size))),
		})


class AutoCF(GeneralModel):
	"""
	AutoCF: Graph CF backbone + learnable augmentation + masked graph autoencoder + teacher distillation.
	Notes:
	- Designed to plug into ReChorus GeneralModel + BaseRunner interface.
	- Teacher checkpoint is expected to be a ReChorus `LightGCN` state_dict by default.
	"""
	reader = 'BaseReader'
	runner = 'AutoCFRunner'
	extra_log_args = [
		'emb_size', 'n_layers', 'ssl_weight', 'distill_weight', 'mask_ratio', 'seedNum',
		'teacher_ckpt_path'
	]

	@staticmethod
	def parse_model_args(parser):
		parser.add_argument('--emb_size', type=int, default=64,
							help='Embedding size.')
		parser.add_argument('--n_layers', type=int, default=3,
							help='LightGCN propagation layers.')
		parser.add_argument('--reg', type=float, default=0.0,
							help='Explicit L2 regularization weight (in addition to optimizer weight_decay).')
		parser.add_argument('--mask_ratio', type=float, default=0.1,
							help='Mask/drop ratio used by augmentation and masked graph autoencoder.')
		parser.add_argument('--seedNum', type=int, default=10,
							help='Number of pre-generated mask seeds for MGAE.')
		parser.add_argument('--ssl_weight', type=float, default=0.1,
							help='Weight of SSL (contrast + reconstruction) loss.')
		parser.add_argument('--distill_weight', type=float, default=0.1,
							help='Weight of teacher distillation loss.')
		parser.add_argument('--ssl_temperature', type=float, default=0.2,
							help='Temperature for InfoNCE.')
		parser.add_argument('--aug_tau', type=float, default=1.0,
							help='Gumbel-sigmoid temperature for learnable augmentation.')
		parser.add_argument('--aug_hard', type=int, default=1,
							help='Use hard (straight-through) masks for augmentation.')
		parser.add_argument('--contrast_weight', type=float, default=1.0,
							help='Weight for contrastive SSL term inside ssl_loss.')
		parser.add_argument('--mgae_weight', type=float, default=1.0,
							help='Weight for masked graph AE recon term inside ssl_loss.')
		parser.add_argument('--teacher_ckpt_path', type=str, default='',
							help='Path to teacher checkpoint (recommended: ReChorus LightGCN .pt state_dict).')
		parser.add_argument('--teacher_n_layers', type=int, default=-1,
							help='Teacher propagation layers (default: same as student).')
		parser.add_argument('--teacher_cache_on_cpu', type=int, default=0,
							help='Cache teacher embeddings on CPU to save GPU memory.')
		parser.add_argument('--teacher_cache_fp16', type=int, default=0,
							help='Cache teacher embeddings in fp16 (memory saving).')
		parser.add_argument('--adj_cache_name', type=str, default='autocf_norm_adj.npz',
							help='Adjacency cache filename under data/<dataset>/.')
		return GeneralModel.parse_model_args(parser)

	@staticmethod
	def init_weights(m):
		if 'Linear' in str(type(m)):
			nn.init.xavier_normal_(m.weight.data)
			if m.bias is not None:
				nn.init.normal_(m.bias.data)
		elif 'Embedding' in str(type(m)):
			nn.init.xavier_normal_(m.weight.data)

	def __init__(self, args, corpus):
		super().__init__(args, corpus)
		self.emb_size = args.emb_size
		self.n_layers = args.n_layers
		self.reg = args.reg
		self.mask_ratio = float(args.mask_ratio)
		self.seedNum = int(args.seedNum)
		self.ssl_weight = args.ssl_weight
		self.distill_weight = args.distill_weight
		self.ssl_temperature = args.ssl_temperature
		self.aug_tau = args.aug_tau
		self.aug_hard = bool(args.aug_hard)
		self.contrast_weight = args.contrast_weight
		self.mgae_weight = args.mgae_weight

		self.teacher_ckpt_path = args.teacher_ckpt_path
		self.teacher_n_layers = args.teacher_n_layers if args.teacher_n_layers and args.teacher_n_layers > 0 else self.n_layers
		self.teacher_cache_on_cpu = bool(args.teacher_cache_on_cpu)
		self.teacher_cache_fp16 = bool(args.teacher_cache_fp16)

		self._mask_ptr = 0
		self._teacher_cached = False
		self.teacher_user_cache = None
		self.teacher_item_cache = None

		self._build_or_load_graph(args, corpus)
		self._define_params()
		self.apply(self.init_weights)
		self._init_mgae_masks(args)
		self._init_teacher(args, corpus)

	def _define_params(self):
		self.user_emb = nn.Embedding(self.user_num, self.emb_size)
		self.item_emb = nn.Embedding(self.item_num, self.emb_size)

		# Learnable augmentation strength (scalar): controls keep probability within [1-mask_ratio, 1]
		keep_init = max(1.0 - self.mask_ratio, 1e-3)
		logit_init = float(np.log(keep_init) - np.log(1.0 - keep_init))
		self.aug_keep_logit = nn.Parameter(torch.tensor(logit_init, dtype=torch.float32))

		# Masked graph autoencoder decoder (reconstruct target embedding from masked embedding)
		self.mgae_decoder = nn.Sequential(
			nn.Linear(self.emb_size, self.emb_size),
			nn.ReLU(),
			nn.Linear(self.emb_size, self.emb_size),
		)

	def _build_or_load_graph(self, args, corpus):
		dataset_dir = os.path.join(args.path, args.dataset)
		adj_cache_path = os.path.join(dataset_dir, args.adj_cache_name)
		os.makedirs(dataset_dir, exist_ok=True)

		if not args.regenerate and os.path.exists(adj_cache_path):
			logging.info('AutoCF: load cached norm_adj from {}'.format(adj_cache_path))
			norm_adj = sp.load_npz(adj_cache_path).tocsr()
		else:
			logging.info('AutoCF: build norm_adj (and cache to {})'.format(adj_cache_path))
			norm_adj = self._build_norm_adj(corpus.n_users, corpus.n_items, corpus.train_clicked_set)
			sp.save_npz(adj_cache_path, norm_adj)

		self.n_nodes = corpus.n_users + corpus.n_items
		if norm_adj.shape[0] != self.n_nodes or norm_adj.shape[1] != self.n_nodes:
			raise ValueError('AutoCF: cached adj shape {} mismatches n_nodes={}'.format(norm_adj.shape, self.n_nodes))

		coo = norm_adj.tocoo()
		indices = torch.from_numpy(np.vstack([coo.row, coo.col]).astype(np.int64))
		values = torch.from_numpy(coo.data.astype(np.float32))
		norm_adj_t = torch.sparse_coo_tensor(indices, values, torch.Size(coo.shape)).coalesce()
		self.register_buffer('norm_adj', norm_adj_t)

	@staticmethod
	def _build_norm_adj(user_count: int, item_count: int, train_clicked_set: dict) -> sp.csr_matrix:
		n_nodes = user_count + item_count
		n_edges = int(sum(len(v) for v in train_clicked_set.values()))
		rows = np.empty(n_edges * 2, dtype=np.int64)
		cols = np.empty(n_edges * 2, dtype=np.int64)
		data = np.ones(n_edges * 2, dtype=np.float32)
		idx = 0
		for u, items in train_clicked_set.items():
			for i in items:
				rows[idx] = u
				cols[idx] = user_count + int(i)
				rows[idx + 1] = user_count + int(i)
				cols[idx + 1] = u
				idx += 2
		adj = sp.coo_matrix((data, (rows, cols)), shape=(n_nodes, n_nodes), dtype=np.float32)

		rowsum = np.array(adj.sum(1)).flatten() + 1e-10
		d_inv_sqrt = np.power(rowsum, -0.5)
		d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.0
		d_mat = sp.diags(d_inv_sqrt)
		norm_adj = d_mat.dot(adj).dot(d_mat).tocsr()
		return norm_adj

	def _init_mgae_masks(self, args):
		# Pre-generate fixed node masks to improve reproducibility.
		if self.seedNum <= 0 or self.mask_ratio <= 0:
			self.register_buffer('node_masks', torch.zeros(1, self.n_nodes, dtype=torch.bool))
			return
		g = torch.Generator()
		base_seed = int(getattr(args, 'random_seed', 0))
		masks = []
		for k in range(self.seedNum):
			g.manual_seed(base_seed + k)
			rnd = torch.rand(self.n_nodes, generator=g)
			masks.append(rnd < self.mask_ratio)
		self.register_buffer('node_masks', torch.stack(masks, dim=0))

	def _init_teacher(self, args, corpus):
		self.teacher = None
		if not self.teacher_ckpt_path:
			return

		if not os.path.exists(self.teacher_ckpt_path):
			raise FileNotFoundError('AutoCF: teacher_ckpt_path not found: {}'.format(self.teacher_ckpt_path))

		ckpt_obj = torch.load(self.teacher_ckpt_path, map_location='cpu')
		state_dict = self._extract_state_dict(ckpt_obj)
		if 'encoder.embedding_dict.user_emb' not in state_dict or 'encoder.embedding_dict.item_emb' not in state_dict:
			raise ValueError('AutoCF: unsupported teacher checkpoint format (expected ReChorus LightGCN state_dict).')

		u_w = state_dict['encoder.embedding_dict.user_emb']
		i_w = state_dict['encoder.embedding_dict.item_emb']
		if u_w.shape[0] != corpus.n_users or i_w.shape[0] != corpus.n_items:
			raise ValueError('AutoCF: teacher ckpt shape mismatch: user {} vs {}, item {} vs {}'.format(
				tuple(u_w.shape), corpus.n_users, tuple(i_w.shape), corpus.n_items))
		if u_w.shape[1] != self.emb_size or i_w.shape[1] != self.emb_size:
			raise ValueError('AutoCF: teacher emb_size mismatch: ckpt {} vs student {}'.format(u_w.shape[1], self.emb_size))

		self.teacher = nn.Module()
		self.teacher.encoder = _LightGCNParamEncoder(corpus.n_users, corpus.n_items, self.emb_size)
		missing, unexpected = self.teacher.load_state_dict(state_dict, strict=False)
		if len(unexpected) > 0:
			logging.info('AutoCF: teacher unexpected keys (ignored): {}'.format(unexpected[:10]))
		if len(missing) > 0:
			logging.info('AutoCF: teacher missing keys (ignored): {}'.format(missing[:10]))

		for p in self.teacher.parameters():
			p.requires_grad = False
		self.teacher.eval()

	@staticmethod
	def _extract_state_dict(ckpt_obj: object) -> dict:
		if isinstance(ckpt_obj, dict):
			# Most common: direct state_dict
			if any(k.startswith('encoder.') for k in ckpt_obj.keys()):
				return ckpt_obj
			for k in ['state_dict', 'model_state_dict', 'model', 'net']:
				if k in ckpt_obj and isinstance(ckpt_obj[k], dict):
					return ckpt_obj[k]
		raise ValueError('AutoCF: cannot extract state_dict from checkpoint object.')

	def _propagate(self, norm_adj: torch.Tensor, ego_embeddings: torch.Tensor, n_layers: int) -> torch.Tensor:
		all_embeddings = [ego_embeddings]
		cur = ego_embeddings
		for _ in range(int(n_layers)):
			cur = torch.sparse.mm(norm_adj, cur)
			all_embeddings.append(cur)
		all_embeddings = torch.stack(all_embeddings, dim=1).mean(dim=1)
		return all_embeddings

	def _gumbel_sigmoid(self, logits: torch.Tensor, tau: float, hard: bool, eps: float = 1e-10) -> torch.Tensor:
		u = torch.rand_like(logits)
		g = -torch.log(-torch.log(u + eps) + eps)
		y = torch.sigmoid((logits + g) / max(tau, eps))
		if hard:
			y_hard = (y > 0.5).float()
			y = (y_hard - y).detach() + y
		return y

	def _sample_aug_mask(self) -> torch.Tensor:
		# keep_prob in [1-mask_ratio, 1]
		drop_strength = torch.sigmoid(self.aug_keep_logit)  # (0,1)
		keep_prob = 1.0 - self.mask_ratio * drop_strength
		keep_prob = keep_prob.clamp(min=1e-3, max=1.0 - 1e-3)
		logit = torch.log(keep_prob) - torch.log(1.0 - keep_prob)
		logits = logit.expand(self.emb_size)
		return self._gumbel_sigmoid(logits, tau=self.aug_tau, hard=self.aug_hard)

	def _info_nce(self, z1: torch.Tensor, z2: torch.Tensor) -> torch.Tensor:
		if z1.size(0) <= 1:
			return torch.zeros([], device=z1.device)
		z1 = F.normalize(z1, dim=-1)
		z2 = F.normalize(z2, dim=-1)
		logits = (z1 @ z2.t()) / max(self.ssl_temperature, 1e-6)
		labels = torch.arange(z1.size(0), device=z1.device)
		return (F.cross_entropy(logits, labels) + F.cross_entropy(logits.t(), labels)) / 2.0

	def _maybe_cache_teacher(self):
		if self.teacher is None or self._teacher_cached:
			return

		cache_device = torch.device('cpu') if self.teacher_cache_on_cpu else self.device
		norm_adj = self.norm_adj
		if cache_device.type == 'cpu' and norm_adj.is_cuda:
			norm_adj = norm_adj.cpu()
		elif cache_device.type == 'cuda' and (not norm_adj.is_cuda):
			norm_adj = norm_adj.to(cache_device)

		with torch.no_grad():
			u_w = self.teacher.encoder.embedding_dict['user_emb'].detach().to(cache_device)
			i_w = self.teacher.encoder.embedding_dict['item_emb'].detach().to(cache_device)
			ego = torch.cat([u_w, i_w], dim=0)
			all_emb = self._propagate(norm_adj, ego, self.teacher_n_layers)
			user_cache = all_emb[:self.user_num].contiguous()
			item_cache = all_emb[self.user_num:].contiguous()
			if self.teacher_cache_fp16:
				user_cache = user_cache.half()
				item_cache = item_cache.half()
			self.teacher_user_cache = user_cache
			self.teacher_item_cache = item_cache
			self._teacher_cached = True
		logging.info('AutoCF: cached teacher embeddings on {}'.format(cache_device))

	def forward(self, feed_dict):
		self.check_list = []
		user = feed_dict['user_id']
		items = feed_dict['item_id']
		if items.dim() == 1:
			items = items.unsqueeze(1)

		ego = torch.cat([self.user_emb.weight, self.item_emb.weight], dim=0)
		all_emb = self._propagate(self.norm_adj, ego, self.n_layers)
		user_all, item_all = all_emb[:self.user_num], all_emb[self.user_num:]

		u_vec = user_all[user]
		i_vec = item_all[items]
		prediction = (u_vec[:, None, :] * i_vec).sum(dim=-1)
		out_dict = {'prediction': prediction}

		if feed_dict['phase'] != 'train':
			return out_dict

		# Teacher distillation (cached once)
		distill_loss = torch.zeros([], device=self.device)
		if self.teacher is not None and self.distill_weight > 0:
			self._maybe_cache_teacher()
			if self.teacher_cache_on_cpu:
				u_cpu = user.detach().cpu()
				i_cpu = items.detach().cpu()
				tu = self.teacher_user_cache[u_cpu].to(self.device, non_blocking=True).float()
				ti = self.teacher_item_cache[i_cpu].to(self.device, non_blocking=True).float()
			else:
				tu = self.teacher_user_cache[user].float()
				ti = self.teacher_item_cache[items].float()
			distill_loss = F.mse_loss(F.normalize(u_vec, dim=-1), F.normalize(tu.detach(), dim=-1)) + \
						  F.mse_loss(F.normalize(i_vec, dim=-1), F.normalize(ti.detach(), dim=-1))

		# Learnable augmentation -> two views (embedding-level) for contrastive SSL
		contrast_loss = torch.zeros([], device=self.device)
		if self.ssl_weight > 0 and self.contrast_weight > 0 and self.mask_ratio > 0:
			m1 = self._sample_aug_mask().to(u_vec.device)
			m2 = self._sample_aug_mask().to(u_vec.device)
			u_v1, u_v2 = u_vec * m1, u_vec * m2
			# pick one (shuffled) item per user to keep SSL cost bounded
			i_one = i_vec[:, 0, :]
			i_v1, i_v2 = i_one * m1, i_one * m2
			contrast_loss = (self._info_nce(u_v1, u_v2) + self._info_nce(i_v1, i_v2)) / 2.0

		# Masked Graph Autoencoder: mask node input embeddings, propagate, and reconstruct masked batch nodes
		recon_loss = torch.zeros([], device=self.device)
		if self.ssl_weight > 0 and self.mgae_weight > 0 and self.mask_ratio > 0:
			mask = self.node_masks[self._mask_ptr % max(self.seedNum, 1)]
			self._mask_ptr += 1
			mask = mask.to(self.device)
			keep = (~mask).float().unsqueeze(-1)
			ego_masked = ego * keep
			all_emb_masked = self._propagate(self.norm_adj, ego_masked, self.n_layers)

			batch_nodes = torch.cat([user, self.user_num + items.reshape(-1)], dim=0)
			batch_nodes = torch.unique(batch_nodes)
			masked_nodes = batch_nodes[mask[batch_nodes]]
			if masked_nodes.numel() > 0:
				recon = self.mgae_decoder(all_emb_masked[masked_nodes])
				target = all_emb[masked_nodes].detach()
				recon_loss = F.mse_loss(recon, target)

		ssl_loss = self.contrast_weight * contrast_loss + self.mgae_weight * recon_loss

		out_dict.update({
			'u_vec': u_vec,
			'i_vec': i_vec,
			'ssl_loss': ssl_loss,
			'contrast_loss': contrast_loss,
			'recon_loss': recon_loss,
			'distill_loss': distill_loss
		})
		return out_dict

	def loss(self, out_dict: dict) -> torch.Tensor:
		rec_loss = super().loss(out_dict)
		ssl_loss = out_dict.get('ssl_loss', torch.zeros([], device=rec_loss.device))
		distill_loss = out_dict.get('distill_loss', torch.zeros([], device=rec_loss.device))

		reg_loss = torch.zeros([], device=rec_loss.device)
		if self.reg > 0 and 'u_vec' in out_dict and 'i_vec' in out_dict:
			u_vec = out_dict['u_vec']
			i_vec = out_dict['i_vec']
			reg_loss = (u_vec.pow(2).sum() + i_vec.pow(2).sum()) / max(u_vec.size(0), 1)

		total = rec_loss + self.ssl_weight * ssl_loss + self.distill_weight * distill_loss + self.reg * reg_loss
		out_dict['rec_loss'] = rec_loss
		out_dict['reg_loss'] = reg_loss
		out_dict['total_loss'] = total
		return total

