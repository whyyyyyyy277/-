# -*- coding: UTF-8 -*-

import torch
import torch.nn as nn
import numpy as np

from models.BaseModel import SequentialModel


class DARE(SequentialModel):
    """Decoupled Attention and Representation Embedding for sequential recommendation."""

    reader = "SeqReader"
    runner = "BaseRunner"
    extra_log_args = ["emb_size", "dropout", "keep_k", "shared_emb", "no_target_interaction"]

    @staticmethod
    def parse_model_args(parser):
        parser.add_argument(
            "--emb_size", type=int, default=64, help="Size of attention/representation embeddings."
        )
        parser.add_argument(
            "--keep_k",
            type=int,
            default=-1,
            help="Optional top-K of recent history to keep before attention (-1 means use full truncated history_max).",
        )
        parser.add_argument(
            "--shared_emb",
            type=int,
            default=0,
            help="If 1, use shared item embedding for attention and representation (ablation).",
        )
        parser.add_argument(
            "--no_target_interaction",
            type=int,
            default=0,
            help="If 1, remove target-aware elementwise interaction (ablation).",
        )
        return SequentialModel.parse_model_args(parser)

    def __init__(self, args, corpus):
        super().__init__(args, corpus)
        self.emb_size = args.emb_size
        self.max_his = args.history_max
        self.keep_k = args.keep_k
        self.shared_emb = bool(args.shared_emb)
        self.no_target_interaction = bool(args.no_target_interaction)
        self.scale = np.sqrt(self.emb_size)
        self.len_range = torch.arange(self.max_his, device=self.device)
        self._define_params()
        self.apply(self.init_weights)

    def _define_params(self):
        # decoupled item embeddings for attention (Q/K) and representation (V)
        self.item_embeddings_att = nn.Embedding(self.item_num, self.emb_size, padding_idx=0)
        if self.shared_emb:
            self.item_embeddings_rep = self.item_embeddings_att
        else:
            self.item_embeddings_rep = nn.Embedding(self.item_num, self.emb_size, padding_idx=0)
        self.position_embeddings = nn.Embedding(
            self.max_his + 1, self.emb_size, padding_idx=0
        )
        self.dropout_layer = nn.Dropout(self.dropout)
        self.score_layer = nn.Linear(self.emb_size, 1)

    def forward(self, feed_dict):
        self.check_list = []
        item_ids = feed_dict["item_id"]  # [B, n_candidates]
        history = feed_dict["history_items"]  # [B, L]
        lengths = feed_dict["lengths"]  # [B]
        batch_size, seq_len = history.shape

        # optional keep_k on recent interactions (ablation for top-K keep)
        if self.keep_k and self.keep_k > 0:
            history = history[:, -self.keep_k :]
            seq_len = history.shape[1]
            lengths = torch.clamp(lengths, max=seq_len)
            valid_his_mask = (history > 0).float()
        else:
            valid_his_mask = (history > 0).float()

        valid_his = valid_his_mask  # padding mask

        # position indices follow SASRec-style counting from the most recent item
        len_range = self.len_range[:seq_len].to(history.device)
        position = (lengths[:, None] - len_range[None, :]) * valid_his
        pos_vectors = self.position_embeddings(position.long())

        # attention branch: use decoupled embeddings plus positional bias
        k_vectors = self.item_embeddings_att(history) + pos_vectors
        q_vectors = self.item_embeddings_att(item_ids)
        k_vectors = self.dropout_layer(k_vectors)
        q_vectors = self.dropout_layer(q_vectors)

        att_logits = torch.matmul(q_vectors, k_vectors.transpose(1, 2)) / self.scale
        att_logits = att_logits.masked_fill(valid_his[:, None, :] == 0, float("-inf"))
        att_weights = torch.softmax(att_logits, dim=-1)
        att_weights = torch.nan_to_num(att_weights, nan=0.0)

        # representation branch: element-wise interaction between history and target
        v_history = self.item_embeddings_rep(history)
        v_history = self.dropout_layer(v_history)

        if self.no_target_interaction:
            # aggregate history only
            weighted = (att_weights.unsqueeze(-1) * v_history.unsqueeze(1)).sum(dim=2)  # [B, C, D]
            weighted = self.dropout_layer(weighted)
            scores = self.score_layer(weighted).squeeze(-1)
        else:
            v_target = self.item_embeddings_rep(item_ids)
            v_target = self.dropout_layer(v_target)
            interact = v_history.unsqueeze(1) * v_target.unsqueeze(2)  # [B, C, L, D]
            weighted = (att_weights.unsqueeze(-1) * interact).sum(dim=2)  # [B, C, D]
            weighted = self.dropout_layer(weighted)
            scores = self.score_layer(weighted).squeeze(-1)

        return {"prediction": scores.view(batch_size, -1)}
