# -*- coding: UTF-8 -*-

import os
import gc
import logging
import numpy as np
import torch
from tqdm import tqdm
from torch.utils.data import DataLoader
from typing import Dict, List

from utils import utils
from models.BaseModel import BaseModel
from helpers.BaseRunner import BaseRunner


class AutoCFRunner(BaseRunner):
	"""
	Runner for AutoCF to log decomposed losses (rec/ssl/distill/total).
	"""

	def train(self, data_dict: Dict[str, BaseModel.Dataset]):
		model = data_dict['train'].model
		main_metric_results, dev_results = list(), list()
		self._check_time(start=True)
		try:
			for epoch in range(self.epoch):
				self._check_time()
				gc.collect()
				torch.cuda.empty_cache()

				loss_dict = self.fit(data_dict['train'], epoch=epoch + 1)
				if np.isnan(loss_dict['total']):
					logging.info("Loss is Nan. Stop training at %d." % (epoch + 1))
					break
				training_time = self._check_time()

				if len(model.check_list) > 0 and self.check_epoch > 0 and epoch % self.check_epoch == 0:
					utils.check(model.check_list)

				dev_result = self.evaluate(data_dict['dev'], [self.main_topk], self.metrics)
				dev_results.append(dev_result)
				main_metric_results.append(dev_result[self.main_metric])

				logging_str = (
					'Epoch {:<5} loss={:<.4f} rec={:<.4f} ssl={:<.4f} distill={:<.4f} [{:<3.1f} s]\tdev=({})'
				).format(
					epoch + 1,
					loss_dict['total'],
					loss_dict['rec'],
					loss_dict['ssl'],
					loss_dict['distill'],
					training_time,
					utils.format_metric(dev_result),
				)

				if self.test_epoch > 0 and epoch % self.test_epoch == 0:
					test_result = self.evaluate(data_dict['test'], self.topk[:1], self.metrics)
					logging_str += ' test=({})'.format(utils.format_metric(test_result))
				testing_time = self._check_time()
				logging_str += ' [{:<.1f} s]'.format(testing_time)

				if max(main_metric_results) == main_metric_results[-1] or \
						(hasattr(model, 'stage') and model.stage == 1):
					model.save_model()
					logging_str += ' *'
				logging.info(logging_str)

				if self.early_stop > 0 and self.eval_termination(main_metric_results):
					logging.info("Early stop at %d based on dev result." % (epoch + 1))
					break

		except KeyboardInterrupt:
			logging.info("Early stop manually")
			exit_here = input("Exit completely without evaluation? (y/n) (default n):")
			if exit_here.lower().startswith('y'):
				logging.info('Early stop without evaluation.')
				exit(1)

		best_epoch = main_metric_results.index(max(main_metric_results))
		logging.info(
			os.linesep + "Best Iter(dev)={:>5}\t dev=({}) [{:<.1f} s] ".format(
				best_epoch + 1, utils.format_metric(dev_results[best_epoch]), self.time[1] - self.time[0]
			)
		)
		model.load_model()

	def fit(self, dataset: BaseModel.Dataset, epoch=-1) -> dict:
		model = dataset.model
		if model.optimizer is None:
			model.optimizer = self._build_optimizer(model)
		dataset.actions_before_epoch()

		model.train()
		loss_total, loss_rec, loss_ssl, loss_distill = [], [], [], []
		dl = DataLoader(dataset, batch_size=self.batch_size, shuffle=True, num_workers=self.num_workers,
						collate_fn=dataset.collate_batch, pin_memory=self.pin_memory)
		for batch in tqdm(dl, leave=False, desc='Epoch {:<3}'.format(epoch), ncols=100, mininterval=1):
			batch = utils.batch_to_gpu(batch, model.device)

			item_ids = batch['item_id']
			indices = torch.argsort(torch.rand(*item_ids.shape, device=item_ids.device), dim=-1)
			batch['item_id'] = item_ids[torch.arange(item_ids.shape[0], device=item_ids.device).unsqueeze(-1), indices]

			model.optimizer.zero_grad()
			out_dict = model(batch)

			prediction = out_dict['prediction']
			if len(prediction.shape) == 2:
				restored = torch.zeros(*prediction.shape, device=prediction.device)
				restored[torch.arange(item_ids.shape[0], device=item_ids.device).unsqueeze(-1), indices] = prediction
				out_dict['prediction'] = restored

			loss = model.loss(out_dict)
			loss.backward()
			model.optimizer.step()

			loss_total.append(loss.detach().cpu().item())
			loss_rec.append(out_dict.get('rec_loss', torch.zeros([], device=loss.device)).detach().cpu().item())
			loss_ssl.append(out_dict.get('ssl_loss', torch.zeros([], device=loss.device)).detach().cpu().item())
			loss_distill.append(out_dict.get('distill_loss', torch.zeros([], device=loss.device)).detach().cpu().item())

		return {
			'total': float(np.mean(loss_total)) if len(loss_total) else 0.0,
			'rec': float(np.mean(loss_rec)) if len(loss_rec) else 0.0,
			'ssl': float(np.mean(loss_ssl)) if len(loss_ssl) else 0.0,
			'distill': float(np.mean(loss_distill)) if len(loss_distill) else 0.0,
		}
