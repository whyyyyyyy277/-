import os
import sys
import argparse
import subprocess


def main():
	parser = argparse.ArgumentParser(description='Minimal AutoCF integration smoke test (teacher + student).')
	parser.add_argument('--dataset', type=str, default='Grocery_and_Gourmet_Food')
	parser.add_argument('--gpu', type=str, default='0', help="Set '' for CPU.")
	parser.add_argument('--emb_size', type=int, default=64)
	parser.add_argument('--n_layers', type=int, default=3)
	parser.add_argument('--batch_size', type=int, default=256)
	parser.add_argument('--eval_batch_size', type=int, default=256)
	parser.add_argument('--num_workers', type=int, default=0)
	parser.add_argument('--teacher_epoch', type=int, default=2)
	parser.add_argument('--student_epoch', type=int, default=3)
	parser.add_argument('--ssl_weight', type=float, default=0.1)
	parser.add_argument('--distill_weight', type=float, default=0.1)
	parser.add_argument('--mask_ratio', type=float, default=0.1)
	parser.add_argument('--seedNum', type=int, default=10)
	parser.add_argument('--skip_teacher', type=int, default=0)
	args = parser.parse_args()

	repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
	main_py = os.path.join(repo_root, 'src', 'main.py')
	log_dir = os.path.join(repo_root, 'log')
	model_dir = os.path.join(repo_root, 'model')
	os.makedirs(log_dir, exist_ok=True)
	os.makedirs(model_dir, exist_ok=True)

	teacher_ckpt = os.path.join(model_dir, 'LightGCN_teacher_smoke.pt')
	teacher_log = os.path.join(log_dir, 'LightGCN_teacher_smoke.txt')
	student_ckpt = os.path.join(model_dir, 'AutoCF_smoke.pt')
	student_log = os.path.join(log_dir, 'AutoCF_smoke.txt')

	if (not args.skip_teacher) or (not os.path.exists(teacher_ckpt)):
		cmd_teacher = [
			sys.executable, main_py,
			'--model_name', 'LightGCN',
			'--dataset', args.dataset,
			'--gpu', args.gpu,
			'--num_workers', str(args.num_workers),
			'--epoch', str(args.teacher_epoch),
			'--batch_size', str(args.batch_size),
			'--eval_batch_size', str(args.eval_batch_size),
			'--emb_size', str(args.emb_size),
			'--n_layers', str(args.n_layers),
			'--model_path', teacher_ckpt,
			'--log_file', teacher_log,
		]
		print('Running teacher:', ' '.join(cmd_teacher))
		subprocess.run(cmd_teacher, cwd=repo_root, check=True)
	else:
		print('Skip teacher training, found:', teacher_ckpt)

	cmd_student = [
		sys.executable, main_py,
		'--model_name', 'AutoCF',
		'--dataset', args.dataset,
		'--gpu', args.gpu,
		'--num_workers', str(args.num_workers),
		'--epoch', str(args.student_epoch),
		'--batch_size', str(args.batch_size),
		'--eval_batch_size', str(args.eval_batch_size),
		'--emb_size', str(args.emb_size),
		'--n_layers', str(args.n_layers),
		'--mask_ratio', str(args.mask_ratio),
		'--seedNum', str(args.seedNum),
		'--ssl_weight', str(args.ssl_weight),
		'--distill_weight', str(args.distill_weight),
		'--teacher_ckpt_path', teacher_ckpt,
		'--model_path', student_ckpt,
		'--log_file', student_log,
	]
	print('Running student:', ' '.join(cmd_student))
	subprocess.run(cmd_student, cwd=repo_root, check=True)

	print('Done.')
	print('Teacher ckpt:', teacher_ckpt)
	print('Student ckpt:', student_ckpt)
	print('Teacher log :', teacher_log)
	print('Student log :', student_log)


if __name__ == '__main__':
	main()

