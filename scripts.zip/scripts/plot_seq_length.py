# -*- coding: utf-8 -*-
"""
Plot user sequence length distribution from one or more train.csv files (columns: user_id, item_id[, time]).

Usage:
    python scripts/plot_seq_length.py --data data/Grocery_and_Gourmet_Food/train.csv data/ML-1M/train.csv \
      --labels Grocery ML1M --out ../log/data_stats/seq_len_overlay.png --bins 50 --xmax 100
"""
import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

plt.style.use("ggplot")
plt.rcParams.update({
    "figure.figsize": (8, 4.5),
    "axes.titlesize": 12,
    "axes.labelsize": 11,
})
COLORS = ["#4C72B0", "#55A868", "#C44E52", "#8172B3", "#CCB974", "#64B5CD"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", nargs="+", required=True, help="One or more train.csv paths (with user_id, item_id columns).")
    parser.add_argument("--labels", nargs="*", default=None, help="Optional labels for each dataset; defaults to file stem.")
    parser.add_argument("--out", required=True, help="Output PNG path.")
    parser.add_argument("--bins", type=int, default=50, help="Number of histogram bins.")
    parser.add_argument("--sep", default="\t", help="CSV separator, default tab.")
    parser.add_argument("--xmax", type=int, default=None, help="Max x-axis length to display (e.g., 100).")
    args = parser.parse_args()

    paths = [Path(p) for p in args.data]
    labels = args.labels if args.labels and len(args.labels) == len(paths) else [p.stem for p in paths]

    plt.figure()
    for idx, (p, lab) in enumerate(zip(paths, labels)):
        df = pd.read_csv(p, sep=args.sep)
        if "user_id" not in df.columns or "item_id" not in df.columns:
            raise ValueError(f"{p} must contain user_id and item_id columns.")
        lengths = df.groupby("user_id")["item_id"].count()
        plt.hist(
            lengths,
            bins=args.bins,
            alpha=0.55,
            color=COLORS[idx % len(COLORS)],
            edgecolor="#333333",
            linewidth=0.4,
            label=lab,
        )

    plt.xlabel("Sequence Length")
    plt.ylabel("Number of Users")
    plt.title("User Sequence Length Distribution")
    if args.xmax:
        plt.xlim(0, args.xmax)
    plt.legend(frameon=False)
    plt.tight_layout()
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, dpi=300)
    plt.close()
    print(f"Saved histogram to: {out_path}")


if __name__ == "__main__":
    main()
