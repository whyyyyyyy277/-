import os
import argparse
import numpy as np
import pandas as pd


def _ensure_dir(path: str):
	os.makedirs(path, exist_ok=True)


def _remap_to_contiguous(df: pd.DataFrame, user_col: str, item_col: str):
	u_vals = df[user_col].unique()
	i_vals = df[item_col].unique()
	u_map = {u: idx + 1 for idx, u in enumerate(u_vals)}  # reserve 0
	i_map = {i: idx + 1 for idx, i in enumerate(i_vals)}
	df = df.copy()
	df['user_id'] = df[user_col].map(u_map).astype(int)
	df['item_id'] = df[item_col].map(i_map).astype(int)
	return df, u_map, i_map


def _per_user_ratio_split(df: pd.DataFrame, train_r: float, dev_r: float, test_r: float, min_user_inter: int):
	assert abs(train_r + dev_r + test_r - 1.0) < 1e-6
	df = df.sort_values(['user_id', 'time']).reset_index(drop=True)
	train_parts, dev_parts, test_parts = [], [], []
	for uid, g in df.groupby('user_id', sort=False):
		n = len(g)
		if n < min_user_inter:
			continue
		train_end = max(1, int(n * train_r))
		dev_end = max(train_end + 1, int(n * (train_r + dev_r)))
		if dev_end >= n:
			dev_end = n - 1
		train_parts.append(g.iloc[:train_end])
		dev_parts.append(g.iloc[train_end:dev_end])
		test_parts.append(g.iloc[dev_end:])
	train_df = pd.concat(train_parts, ignore_index=True) if train_parts else df.iloc[:0].copy()
	dev_df = pd.concat(dev_parts, ignore_index=True) if dev_parts else df.iloc[:0].copy()
	test_df = pd.concat(test_parts, ignore_index=True) if test_parts else df.iloc[:0].copy()
	return train_df, dev_df, test_df


def _sample_negatives(rng: np.random.RandomState, clicked_set: set, n_items: int, n_neg: int):
	if n_neg <= 0:
		return []
	negs = set()
	# oversample to reduce python loop overhead
	while len(negs) < n_neg:
		cands = rng.randint(1, n_items, size=n_neg * 4)
		for c in cands:
			c = int(c)
			if c not in clicked_set and c not in negs:
				negs.add(c)
				if len(negs) >= n_neg:
					break
	return list(negs)


def _attach_eval_negs(train_df: pd.DataFrame, dev_df: pd.DataFrame, test_df: pd.DataFrame, n_items: int, eval_neg: int, seed: int):
	rng = np.random.RandomState(seed)
	user_clicked = dict()
	for df in [train_df, dev_df, test_df]:
		for uid, iid in zip(df['user_id'].values, df['item_id'].values):
			user_clicked.setdefault(int(uid), set()).add(int(iid))

	def add_negs(df: pd.DataFrame):
		neg_lists = []
		for uid in df['user_id'].values:
			neg_lists.append(_sample_negatives(rng, user_clicked.get(int(uid), set()), n_items, eval_neg))
		df = df.copy()
		df['neg_items'] = [str(x) for x in neg_lists]
		return df

	return add_negs(dev_df), add_negs(test_df)


def _read_official_pairs(file_path: str, id_offset: int):
	# Expect whitespace-separated `user item` (optional third column as time).
	df = pd.read_csv(file_path, sep=r'\s+', header=None, engine='python')
	if df.shape[1] < 2:
		raise ValueError('Invalid split file (need at least 2 columns): {}'.format(file_path))
	df = df.iloc[:, :3].copy()
	if df.shape[1] == 2:
		df.columns = ['user_id', 'item_id']
		df['time'] = np.arange(len(df), dtype=np.int64)
	else:
		df.columns = ['user_id', 'item_id', 'time']
	df['user_id'] = df['user_id'].astype(int) + int(id_offset)
	df['item_id'] = df['item_id'].astype(int) + int(id_offset)
	df['time'] = df['time'].astype(np.int64)
	return df


def main():
	parser = argparse.ArgumentParser(description='Prepare ReChorus-style train/dev/test csv for AutoCF.')
	parser.add_argument('--input', type=str, default='',
						help='Raw interaction file path (csv/tsv). Ignored when --official_split_dir is set.')
	parser.add_argument('--input_sep', type=str, default='\t',
						help='Separator for --input.')
	parser.add_argument('--user_col', type=str, default='user_id')
	parser.add_argument('--item_col', type=str, default='item_id')
	parser.add_argument('--time_col', type=str, default='time')
	parser.add_argument('--dataset', type=str, required=True,
						help='Output dataset folder name under --out_dir.')
	parser.add_argument('--out_dir', type=str, default='data')
	parser.add_argument('--out_sep', type=str, default='\t')
	parser.add_argument('--seed', type=int, default=2024)
	parser.add_argument('--split', type=str, default='0.7,0.05,0.25',
						help='Per-user ratio split: train,dev,test')
	parser.add_argument('--min_user_inter', type=int, default=3,
						help='Drop users with interactions less than this.')
	parser.add_argument('--eval_neg', type=int, default=99,
						help='Number of negative items per dev/test row.')
	parser.add_argument('--remap', type=int, default=1,
						help='Whether to remap user/item ids to contiguous ids starting from 1.')
	parser.add_argument('--official_split_dir', type=str, default='',
						help='Directory containing train.txt/valid.txt/test.txt in `user item [time]` format.')
	parser.add_argument('--official_id_offset', type=int, default=1,
						help='ID offset applied to official split ids (default 1 to shift 0-based -> 1-based).')
	args = parser.parse_args()

	out_path = os.path.join(args.out_dir, args.dataset)
	_ensure_dir(out_path)

	if args.official_split_dir:
		train_df = _read_official_pairs(os.path.join(args.official_split_dir, 'train.txt'), args.official_id_offset)
		dev_df = _read_official_pairs(os.path.join(args.official_split_dir, 'valid.txt'), args.official_id_offset)
		test_df = _read_official_pairs(os.path.join(args.official_split_dir, 'test.txt'), args.official_id_offset)
		all_df = pd.concat([train_df, dev_df, test_df], ignore_index=True)
		n_items = int(all_df['item_id'].max()) + 1
	else:
		if args.input == '':
			raise ValueError('Provide --input, or set --official_split_dir.')
		raw = pd.read_csv(args.input, sep=args.input_sep)
		if args.time_col not in raw.columns:
			raw[args.time_col] = np.arange(len(raw), dtype=np.int64)

		if args.remap:
			df, _, _ = _remap_to_contiguous(raw, args.user_col, args.item_col)
			df['time'] = raw[args.time_col].astype(np.int64).values
		else:
			df = raw.rename(columns={args.user_col: 'user_id', args.item_col: 'item_id', args.time_col: 'time'})[
				['user_id', 'item_id', 'time']
			].copy()
			df['user_id'] = df['user_id'].astype(int)
			df['item_id'] = df['item_id'].astype(int)
			df['time'] = df['time'].astype(np.int64)

		train_r, dev_r, test_r = [float(x) for x in args.split.split(',')]
		train_df, dev_df, test_df = _per_user_ratio_split(df, train_r, dev_r, test_r, args.min_user_inter)
		n_items = int(df['item_id'].max()) + 1

	dev_df, test_df = _attach_eval_negs(train_df, dev_df, test_df, n_items=n_items, eval_neg=args.eval_neg, seed=args.seed)

	train_df = train_df[['user_id', 'item_id', 'time']].sort_values(['user_id', 'time'])
	dev_df = dev_df[['user_id', 'item_id', 'time', 'neg_items']].sort_values(['user_id', 'time'])
	test_df = test_df[['user_id', 'item_id', 'time', 'neg_items']].sort_values(['user_id', 'time'])

	train_df.to_csv(os.path.join(out_path, 'train.csv'), sep=args.out_sep, index=False)
	dev_df.to_csv(os.path.join(out_path, 'dev.csv'), sep=args.out_sep, index=False)
	test_df.to_csv(os.path.join(out_path, 'test.csv'), sep=args.out_sep, index=False)

	print('Saved:')
	print('  {}'.format(os.path.join(out_path, 'train.csv')))
	print('  {}'.format(os.path.join(out_path, 'dev.csv')))
	print('  {}'.format(os.path.join(out_path, 'test.csv')))
	print('n_users={}, n_items={}'.format(int(max(train_df.user_id.max(), dev_df.user_id.max(), test_df.user_id.max())) + 1,
										n_items))


if __name__ == '__main__':
	main()

