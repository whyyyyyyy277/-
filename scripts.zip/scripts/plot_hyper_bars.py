# -*- coding: utf-8 -*-
"""
Plot hyper-parameter comparison bars from multiple log files.

Usage:
    python scripts/plot_hyper_bars.py --logs \
      K5=../log/DARE/run_dare_ml1m_k5.txt \
      K10=../log/DARE/run_dare_ml1m_k10.txt \
      K20=../log/DARE/run_dare_ml1m_k20.txt \
      K50=../log/DARE/run_dare_ml1m_k50.txt \
      --out ../log/DARE/plots_hyper_k --metric_hr HR@10 --metric_ndcg NDCG@10
"""
import argparse
import re
from pathlib import Path

import matplotlib.pyplot as plt

plt.style.use("ggplot")
plt.rcParams.update({
    "figure.figsize": (5, 4.2),  # slightly wider for grouped bars
    "axes.titlesize": 12,
    "axes.labelsize": 10,
    "legend.fontsize": 9,
    "font.family": "DejaVu Sans",
})
BAR_COLOR1 = "#FFA94D"  # bright orange for HR
BAR_COLOR2 = "#4C72B0"  # blue for NDCG


def parse_metric(log_path: Path, metric_key: str) -> float:
    # metric_key format: HR@10 or NDCG@10
    pattern = re.compile(rf"{re.escape(metric_key)}:([\d\.]+)")
    val = None
    for line in log_path.read_text(encoding="utf-8").splitlines():
        m = pattern.search(line)
        if m:
            val = float(m.group(1))
    if val is None:
        raise ValueError(f"Cannot find {metric_key} in {log_path}")
    return val


def plot_grouped(labels, hr_vals, ndcg_vals, title, out_file, metric_hr, metric_ndcg):
    plt.figure()
    x = range(len(labels))
    width = 0.35
    bars1 = plt.bar([xi - width / 2 for xi in x], hr_vals, width=width, color=BAR_COLOR1, alpha=0.9,
                    edgecolor="#333333", linewidth=0.5, label=metric_hr)
    bars2 = plt.bar([xi + width / 2 for xi in x], ndcg_vals, width=width, color=BAR_COLOR2, alpha=0.9,
                    edgecolor="#333333", linewidth=0.5, label=metric_ndcg)
    plt.xticks(list(x), labels, rotation=10)
    plt.ylabel("Score")
    plt.title(title, pad=8)
    plt.grid(True, axis="y", alpha=0.2, linestyle="--")
    for bar, v in zip(bars1, hr_vals):
        plt.text(bar.get_x() + bar.get_width() / 2, v, f"{v:.3f}", ha="center", va="bottom", fontsize=8)
    for bar, v in zip(bars2, ndcg_vals):
        plt.text(bar.get_x() + bar.get_width() / 2, v, f"{v:.3f}", ha="center", va="bottom", fontsize=8)
    plt.legend(frameon=False)
    plt.tight_layout()
    plt.savefig(out_file, dpi=300)
    plt.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--logs", nargs="+", required=True, help="List of name=path pairs.")
    parser.add_argument("--out", required=True, help="Output directory for bar charts.")
    parser.add_argument("--metric_hr", default="HR@10", help="Metric key for HR-like plot.")
    parser.add_argument("--metric_ndcg", default="NDCG@10", help="Metric key for NDCG-like plot.")
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    labels, hr_vals, ndcg_vals = [], [], []
    for pair in args.logs:
        if "=" not in pair:
            raise ValueError("Use name=path format for --logs")
        name, path = pair.split("=", 1)
        log_path = Path(path)
        labels.append(name)
        hr_vals.append(parse_metric(log_path, args.metric_hr))
        ndcg_vals.append(parse_metric(log_path, args.metric_ndcg))

    plot_grouped(labels, hr_vals, ndcg_vals, f"{args.metric_hr} & {args.metric_ndcg}", out_dir / "metrics.png",
                 args.metric_hr, args.metric_ndcg)
    print(f"Saved grouped bar chart to {out_dir}")


if __name__ == "__main__":
    main()
