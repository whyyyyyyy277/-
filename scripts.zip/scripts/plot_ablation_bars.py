# -*- coding: utf-8 -*-
"""
Aggregate HR@10 / NDCG@10 from multiple log files and draw bar charts.

Usage:
    python scripts/plot_ablation_bars.py --logs \
      DARE=../log/DARE/run_dare_ml1m_gpu0_001.txt \
      Shared=../log/DARE/run_dare_ml1m_shared.txt \
      NoTgt=../log/DARE/run_dare_ml1m_no_tgt.txt \
      FullSeq=../log/DARE/run_dare_ml1m_fullseq.txt \
      --out ../log/DARE/plots_ablation_ml1m
"""
import argparse
import re
from pathlib import Path

import matplotlib.pyplot as plt

plt.style.use("ggplot")
plt.rcParams.update({
    "figure.figsize": (8, 4),
    "axes.titlesize": 13,
    "axes.labelsize": 11,
    "legend.fontsize": 10,
    "font.family": "DejaVu Sans",
})
BAR_COLORS = ["#4C72B0", "#55A868", "#C44E52", "#8172B3", "#CCB974", "#64B5CD"]


def parse_log(log_path: Path):
    hr10 = ndcg10 = None
    pattern = re.compile(r"HR@10:([\d\.]+).*?NDCG@10:([\d\.]+)")
    for line in log_path.read_text(encoding="utf-8").splitlines():
        m = pattern.search(line)
        if m:
            hr10 = float(m.group(1))
            ndcg10 = float(m.group(2))
    if hr10 is None or ndcg10 is None:
        raise ValueError(f"Cannot find HR@10/NDCG@10 in {log_path}")
    return hr10, ndcg10


def plot_bars(labels, values, title, ylabel, out_file):
    plt.figure()
    x = range(len(labels))
    colors = [BAR_COLORS[i % len(BAR_COLORS)] for i in x]
    # shadow layer to模拟立体感
    shadow = plt.bar(
        [xi + 0.05 for xi in x],
        values,
        width=0.6,
        color="#999999",
        alpha=0.25,
        linewidth=0,
        zorder=0,
    )
    bars = plt.bar(
        x,
        values,
        width=0.6,
        color=colors,
        alpha=0.95,
        edgecolor="#333333",
        linewidth=0.7,
        zorder=2,
    )
    plt.xticks(x, labels, rotation=15)
    plt.ylabel(ylabel)
    plt.title(title, pad=10)
    plt.grid(True, axis="y", alpha=0.25, linestyle="--")
    for bar, v in zip(bars, values):
        plt.text(bar.get_x() + bar.get_width() / 2, v, f"{v:.3f}", ha="center", va="bottom", fontsize=9)
    plt.tight_layout()
    plt.savefig(out_file, dpi=300)
    plt.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--logs", nargs="+", required=True, help="List of name=path pairs.")
    parser.add_argument("--out", required=True, help="Output directory for bar charts.")
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    labels, hr_vals, ndcg_vals = [], [], []
    for pair in args.logs:
        if "=" not in pair:
            raise ValueError("Use name=path format for --logs")
        name, path = pair.split("=", 1)
        hr10, ndcg10 = parse_log(Path(path))
        labels.append(name)
        hr_vals.append(hr10)
        ndcg_vals.append(ndcg10)

    plot_bars(labels, hr_vals, "HR@10", "HR@10", out_dir / "hr10.png")
    plot_bars(labels, ndcg_vals, "NDCG@10", "NDCG@10", out_dir / "ndcg10.png")
    print(f"Saved bar charts to {out_dir}")


if __name__ == "__main__":
    main()
