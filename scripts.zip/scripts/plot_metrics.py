# -*- coding: utf-8 -*-
"""
Parse ReChorus training日志并生成指标曲线图（loss、HR@k、NDCG@k等）
用法示例：
    python scripts/plot_metrics.py --log ../log/DARE/DARE__Grocery_and_Gourmet_Food__0__lr=0.txt
可选参数：
    --out  输出目录（默认与日志同目录下的 plots 子目录）
    --metrics  只绘制指定指标（如: --metrics HR@5 HR@10 NDCG@5）
"""

import argparse
import re
from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt

# basic style tuning for clearer plots
plt.style.use("ggplot")
plt.rcParams.update({
    "figure.figsize": (8, 4),
    "axes.titlesize": 12,
    "axes.labelsize": 11,
    "legend.fontsize": 9,
    "lines.linewidth": 2.0,
})
COLOR_DEV = "#1f77b4"
COLOR_TEST = "#ff7f0e"
COLOR_LOSS = "#2ca02c"


def parse_metric_block(block: str) -> Dict[str, float]:
    metrics = {}
    for token in block.split(','):
        token = token.strip()
        if not token:
            continue
        if ':' not in token:
            continue
        name, val = token.split(':', 1)
        try:
            metrics[name.strip()] = float(val)
        except ValueError:
            continue
    return metrics


def parse_log(log_path: Path) -> Tuple[List[int], List[float], Dict[str, List[float]], Dict[str, List[float]]]:
    epochs, losses = [], []
    dev_metrics: Dict[str, List[float]] = {}
    test_metrics: Dict[str, List[float]] = {}

    # 示例行：Epoch 1     loss=0.1234 [  1.2 s]  dev=(HR@5:0.1,NDCG@5:0.05) test=(...)
    # 更宽松匹配，允许行首有空格/其他前缀
    pattern_epoch = re.compile(r"Epoch\s+(\d+)\s+loss=([-\d\.eE]+).*?dev=\(([^)]*)\)")
    pattern_test = re.compile(r"test=\(([^)]*)\)")

    with log_path.open("r", encoding="utf-8") as f:
        for line in f:
            m = pattern_epoch.search(line)
            if not m:
                continue
            epoch = int(m.group(1))
            loss = float(m.group(2))
            dev_block = m.group(3)
            test_block = None
            tmatch = pattern_test.search(line)
            if tmatch:
                test_block = tmatch.group(1)

            dev_parsed = parse_metric_block(dev_block)
            test_parsed = parse_metric_block(test_block) if test_block else {}

            epochs.append(epoch)
            losses.append(loss)
            for k, v in dev_parsed.items():
                dev_metrics.setdefault(k, []).append(v)
            for k in dev_metrics.keys():
                if k not in test_parsed:
                    # 对齐长度（无测试值则填 None）
                    test_metrics.setdefault(k, []).append(None)
            for k, v in test_parsed.items():
                test_metrics.setdefault(k, []).append(v)
                if k not in dev_metrics:
                    dev_metrics[k] = [None] * (len(epochs) - 1)
    return epochs, losses, dev_metrics, test_metrics


def plot_curves(epochs: List[int], losses: List[float], dev: Dict[str, List[float]],
                test: Dict[str, List[float]], out_dir: Path, metrics_filter=None):
    out_dir.mkdir(parents=True, exist_ok=True)

    # loss 曲线
    plt.figure()
    plt.plot(epochs, losses, label="loss", color=COLOR_LOSS, marker="o", ms=3, alpha=0.8)
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("Training Loss")
    plt.grid(True, alpha=0.3, linestyle="--")
    plt.legend(frameon=False)
    plt.tight_layout()
    plt.savefig(out_dir / "loss.png", dpi=200)
    plt.close()

    # 指标曲线
    for metric, dev_vals in dev.items():
        if metrics_filter and metric not in metrics_filter:
            continue
        test_vals = test.get(metric, [])
        plt.figure()
        plt.plot(epochs, dev_vals, label="dev", marker="o", ms=3, color=COLOR_DEV, alpha=0.9)
        if any(v is not None for v in test_vals):
            plt.plot(epochs, test_vals, label="test", marker="x", ms=4, color=COLOR_TEST, alpha=0.9)
        plt.xlabel("Epoch")
        plt.ylabel(metric)
        plt.title(metric)
        plt.grid(True, alpha=0.3, linestyle="--")
        plt.legend(frameon=False)
        plt.tight_layout()
        plt.savefig(out_dir / f"{metric.replace('@', '_')}.png", dpi=200)
        plt.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--log", required=True, help="日志文件路径，如 ../log/DARE/DARE__Grocery_and_Gourmet_Food__0__lr=0.txt")
    parser.add_argument("--out", default=None, help="输出目录，默认 log 同目录下 plots 子目录")
    parser.add_argument("--metrics", nargs="*", default=None, help="仅绘制指定指标，如 HR@5 HR@10 NDCG@5")
    args = parser.parse_args()

    log_path = Path(args.log).expanduser().resolve()
    out_dir = Path(args.out).expanduser().resolve() if args.out else log_path.parent / "plots"

    epochs, losses, dev_metrics, test_metrics = parse_log(log_path)
    if not epochs:
        raise SystemExit("未在日志中解析到任何 Epoch 行，请确认日志路径是否正确，以及训练是否完成。")

    plot_curves(epochs, losses, dev_metrics, test_metrics, out_dir, metrics_filter=set(args.metrics) if args.metrics else None)
    print(f"已生成图像到: {out_dir}")


if __name__ == "__main__":
    main()
